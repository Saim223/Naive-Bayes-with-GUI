// Enhanced JavaScript for card interactions
document.addEventListener('DOMContentLoaded', function() {
    const modelCards = document.querySelectorAll('.model-card');
    
    // Add click event listeners to all model cards
    modelCards.forEach(card => {
        card.addEventListener('click', function(e) {
            // Prevent triggering if clicking on links or buttons inside the card
            if (e.target.tagName === 'A' || e.target.tagName === 'BUTTON' || e.target.closest('a') || e.target.closest('button')) {
                return;
            }
            
            const modelType = this.getAttribute('data-model');
            if (modelType) {
                // Add click feedback
                this.style.transform = 'scale(0.95)';
                setTimeout(() => {
                    this.style.transform = '';
                    window.location.href = `/predict/${modelType}`;
                }, 150);
            }
        });
        
        // Add hover sound effect (optional)
        card.addEventListener('mouseenter', function() {
            this.style.cursor = 'pointer';
        });
        
        // Add keyboard accessibility
        card.addEventListener('keypress', function(e) {
            if (e.key === 'Enter' || e.key === ' ') {
                e.preventDefault();
                const modelType = this.getAttribute('data-model');
                if (modelType) {
                    window.location.href = `/predict/${modelType}`;
                }
            }
        });
        
        // Make cards focusable for accessibility
        card.setAttribute('tabindex', '0');
    });
    
    // Add ripple effect to cards
    function createRipple(event) {
        const card = event.currentTarget;
        const circle = document.createElement('span');
        const diameter = Math.max(card.clientWidth, card.clientHeight);
        const radius = diameter / 2;
        
        circle.style.width = circle.style.height = `${diameter}px`;
        circle.style.left = `${event.clientX - card.offsetLeft - radius}px`;
        circle.style.top = `${event.clientY - card.offsetTop - radius}px`;
        circle.classList.add('ripple');
        
        const ripple = card.getElementsByClassName('ripple')[0];
        if (ripple) {
            ripple.remove();
        }
        
        card.appendChild(circle);
    }
    
    modelCards.forEach(card => {
        card.addEventListener('click', createRipple);
    });
});

// Add CSS for ripple effect
const style = document.createElement('style');
style.textContent = `
    .ripple {
        position: absolute;
        border-radius: 50%;
        background-color: rgba(255, 255, 255, 0.7);
        transform: scale(0);
        animation: ripple-animation 0.6s linear;
        pointer-events: none;
    }
    
    @keyframes ripple-animation {
        to {
            transform: scale(4);
            opacity: 0;
        }
    }
    
    .model-card {
        position: relative;
        overflow: hidden;
    }
`;
document.head.appendChild(style);